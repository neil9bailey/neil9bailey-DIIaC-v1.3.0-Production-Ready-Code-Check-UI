# DIIaC Board Report - bb4d6134-32db-574e-aa5d-aa8c4f09e05e

- Schema: GENERAL_SOLUTION_BOARD_REPORT_V1
- Profile: transport_profile_v1

## Executive Summary
objective: Select resilient SD-WAN strategy with auditable controls and lower 5-year TCO.
recommendation: Decision not recommended pending control remediation (selected_vendor=no approved selection, score=83.17).

## Context
Schema=GENERAL_SOLUTION_BOARD_REPORT_V1; Jurisdiction=UK; Risk appetite=LOW. Roles engaged (1): CIO. Domains covered: network-transformation. Governance modes: FIRST-PRINCIPLES MODE, DEVIL'S ADVOCATE MODE, CONSTRAINTS-FIRST MODE.

## Risk Register
- Migration disruption
- Vendor lock-in

## Success Metrics
- 20% incident reduction
- GDPR compliance
- NIS2 compliance

## Down-Select Recommendation
Decision not recommended pending control remediation with deterministic weighted score 83.17.

## Major Recommendations
- Decision not recommended pending control remediation: score=83.17
  - Option profile: HybridScale Cloud Platform | focus=Multi-cloud orchestration with cost governance and workload portability | rank=1
  - Alternatives considered: GovCloud Managed Infrastructure, SecureStack Container Services
  - Driver: Top weighted score under deterministic evaluation (83.17)
  - Driver: Solution focus: Multi-cloud orchestration with cost governance and workload portability
  - Driver: Aligned with required controls and governance policy constraints
  - Driver: Supports measurable resilience, security and operating model outcomes
  - Driver: CONSTRAINTS-FIRST controls inferred from active business profile
  - Evidence IDs: REF-RAIL-001: UK rail network SD-WAN transformation mandate, claim-1, claim-2, claim-3
  - Assumptions:
    - Cost model assumptions are based on provided capex/opex targets and current market benchmarks.
    - Operational baseline and incident data provided in role evidence is assumed accurate and current.
    - Supplier capability statements and migration constraints captured in assertions are assumed complete.
  - Risk treatment strategy: mitigate
    - Contractual protections and break clauses to reduce lock-in risk
    - Phased migration with rollback controls to reduce service disruption
    - Security validation and assurance gates prior to production cutover
  - Confidence: LOW (43.17) - Confidence is derived from deterministic scoring, control compliance, evidence quality/freshness, and governance mode checks.

## Ranked Option Detail
- #1 HybridScale Cloud Platform | score=83.17 | focus=Multi-cloud orchestration with cost governance and workload portability
  - Fit breakdown: security=94.97, delivery=77.69, operating_model=78.04, financial=85.45
  - Regulatory alignment signals: GDPR, NIS2, Compliance Requirement
  - Security priorities detected: Audit Controls
  - Financial constraints: Vendor lock-in risk detected
- #2 GovCloud Managed Infrastructure | score=81.82 | focus=Sovereign cloud hosting with regulatory-aligned operational controls
  - Fit breakdown: security=84.6, delivery=70.77, operating_model=93.85, financial=75.29
  - Regulatory alignment signals: GDPR, NIS2, Compliance Requirement
  - Security priorities detected: Audit Controls
  - Financial constraints: Vendor lock-in risk detected
- #3 SecureStack Container Services | score=65.85 | focus=Hardened container platform with deterministic deployment pipelines
  - Fit breakdown: security=70.23, delivery=65.92, operating_model=54.07, financial=76.27
  - Regulatory alignment signals: GDPR, NIS2, Compliance Requirement
  - Security priorities detected: Audit Controls
  - Financial constraints: Vendor lock-in risk detected

## Intent Coverage
- Regulatory constraints: GDPR, NIS2, Compliance Requirement
- Security constraints: Audit Controls
- Financial constraints: Vendor lock-in risk detected
- Success targets: incident

## Decision Summary
- Status: not_recommended
- Confidence: LOW (43.17)
- Basis: Deterministic weighted scoring + profile/policy controls + role evidence
- Control Failure Reasons:
  - policy_pack_control_failed:EU-AIA-ART10-DATA-GOVERNANCE
  - policy_pack_control_failed:EU-AIA-ART15-ACCURACY-ROBUSTNESS
  - policy_pack_control_failed:UK-DUAA-2025-QUALITY-ASSURANCE
- Quality Gate Failures:
  - strong evidence refs 0 below minimum 2
  - evidence coverage 0.00 below minimum 0.60
- Policy Pack Summary:
  - eu_ai_act_deployer_v1: fail_count=2
  - uk_ai_governance_v1: fail_count=1

## Implementation Plan
- Phase 1 (0-30 days): baseline architecture, migration wave plan, and KPI instrumentation.
- Phase 2 (31-90 days): pilot deployment with zero-downtime controls and security hardening.
- Phase 3 (91-180 days): scaled rollout, assurance audits, and benefits realization tracking.
